{{- define "labels" }}
  {{- range $key, $val := .Values.metadate.labels }}
    {{ $key }}: {{ $val | quote }}
  {{- end }}
{{- end }}